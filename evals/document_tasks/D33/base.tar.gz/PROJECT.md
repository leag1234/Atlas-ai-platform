Ship only to France or Germany. Never ship outside these countries.
