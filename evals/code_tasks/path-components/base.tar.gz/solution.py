def safe_path(value):
    return not value.startswith('/')
