def render(text, values, defaults):
    return text.format(**values)
