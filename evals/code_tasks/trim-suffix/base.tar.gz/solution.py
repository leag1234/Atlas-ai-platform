def trim_suffix(value, suffix):
    return value.rstrip(suffix)
