def build(base, parts, query):
    path = '/'.join(parts)
    return base + '/' + path + '?' + '&'.join(f'{key}={value}' for key, value in query.items())
