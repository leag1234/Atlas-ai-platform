def headers(defaults, custom):
    merged = dict(custom)
    merged.update(defaults)
    return merged
