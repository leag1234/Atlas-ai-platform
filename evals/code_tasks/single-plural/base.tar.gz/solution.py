def label(count):
    return f'{count} files'
