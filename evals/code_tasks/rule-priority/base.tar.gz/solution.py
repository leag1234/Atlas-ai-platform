def choose(rules, value):
    return next(rule['name'] for rule in rules if value >= rule['minimum'])
