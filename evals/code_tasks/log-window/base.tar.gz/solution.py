def recent(text, count):
    return text.split('\n')[-count:]
