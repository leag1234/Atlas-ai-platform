def table(rows):
    widths = [len(cell) for cell in rows[0]]
    return '\n'.join(' | '.join(cell.ljust(widths[index]) for index, cell in enumerate(row)) for row in rows)
