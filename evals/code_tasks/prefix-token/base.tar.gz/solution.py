def allowed(values, wanted):
    return any(item.startswith(wanted) for item in values.split(','))
