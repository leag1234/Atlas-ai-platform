def overlay(base, override):
    result = dict(base)
    result.update(override)
    return result
