def display_name(value):
    return value if value is not None else 'untitled'
