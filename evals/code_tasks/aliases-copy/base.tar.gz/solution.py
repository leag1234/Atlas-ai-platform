def records(names):
    aliases = []
    return {name: aliases for name in names}
