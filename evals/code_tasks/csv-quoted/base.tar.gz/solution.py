def fields(text):
    return [part.strip() for part in text.split(',')]
