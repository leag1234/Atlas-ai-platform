def page(items, number, size):
    return items[number * size + 1:(number + 1) * size + 1]
