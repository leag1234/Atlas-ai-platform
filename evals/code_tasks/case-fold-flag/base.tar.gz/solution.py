def enabled(value):
    return value in {'true', 'yes', '1'}
