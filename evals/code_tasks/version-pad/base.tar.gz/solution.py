def newer(left, right):
    return tuple(map(int, left.split('.'))) > tuple(map(int, right.split('.')))
