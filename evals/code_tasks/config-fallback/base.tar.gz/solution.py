def setting(env, name, default):
    return default if env.get(name) else env.get(name)
