def attempts(retries):
    return list(range(retries))
