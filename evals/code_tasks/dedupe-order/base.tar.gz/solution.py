def unique(values):
    return list(reversed(list(dict.fromkeys(values))))
