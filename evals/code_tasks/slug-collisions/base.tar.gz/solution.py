def slugs(titles):
    return [title.lower().replace(' ', '-') for title in titles]
