def order(graph):
    return list(graph)
