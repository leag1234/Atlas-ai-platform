def numbers(first, last):
    return list(range(first, last))
