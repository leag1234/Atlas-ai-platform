def summarize(events):
    return {kind: sum(event['kind'] == kind for event in events) for kind in sorted({event['kind'] for event in events})}
